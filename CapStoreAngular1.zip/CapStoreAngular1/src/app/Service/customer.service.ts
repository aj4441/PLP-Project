import { Injectable } from '@angular/core';
import { Product } from '../Model/Product';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private products: Product[];

  //array having multiple products saved
  constructor() {
    this.products = [
      { id: '101', name: 'Shoes', photo: '/assets/Watch.jfif', price: 500 },
      { id: '102', name: 'Watch', photo: '/assets/RCT-Shoes.jpg', price: 1000 },
      { id: '103', name: 'Mobile', photo: '/assets/mobile.jpg', price: 15000 },
      { id: '104', name: 'Power Bank', photo: '/assets/mobile.jpg', price: 1500 },
      { id: '105', name: 'Shirts', photo: '/assets/mobile.jpg', price: 700 },
      { id: '106', name: 'Bag', photo: '/assets/mobile.jpg', price: 600 },
      { id: '107', name: 'Laptop', photo: '/assets/mobile.jpg', price: 45000 },
      { id: '108', name: 'Hand Bags', photo: '/assets/mobile.jpg', price: 350 }
    ];
  }
  findAll(): Product[] {
    return this.products;
  }
  find(id: string): Product {
    return this.products[this.getSelectedIndex(id)];
}
private getSelectedIndex(id: string) {
  for (var i = 0; i < this.products.length; i++) {
      if (this.products[i].id == id) {
          return i;
      }
  }
  return -1;
}
}
